package com.example.EmployeeManagementSystem.mapper;

import com.example.EmployeeManagementSystem.dto.DtoEmployee;
import com.example.EmployeeManagementSystem.model.Employee;

public class MapperEmployee {
    public static Employee mapTOEmployee(DtoEmployee dtoEmployee){
         Employee employee = new Employee();
         employee.setFirstname(dtoEmployee.getFirstname());
         employee.setLastname(dtoEmployee.getLastname());
         employee.setEmail(dtoEmployee.getEmail());
         return employee;
    }
    public static DtoEmployee mapToDtoEmployee(Employee employee){
        return new DtoEmployee(
                employee.getId(),
                employee.getFirstname(),
                employee.getLastname(),
                employee.getEmail()
        );
    }

}
