package com.example.EmployeeManagementSystem.exception;

public class ExceptionEmployee extends RuntimeException {
    public ExceptionEmployee(String message) {
        super(message);
    }
}
